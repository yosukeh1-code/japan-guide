import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { ItineraryGenerator } from './components/ItineraryGenerator';
import { ChatBot } from './components/ChatBot';
import { CultureGuide } from './components/CultureGuide';
import { View } from './types';

const App: React.FC = () => {
  const [currentView, setView] = useState<View>(View.HOME);

  const renderContent = () => {
    switch (currentView) {
      case View.HOME:
        return <Hero setView={setView} />;
      case View.PLANNER:
        return <ItineraryGenerator />;
      case View.CHAT:
        return <ChatBot />;
      case View.CULTURE:
        return <CultureGuide />;
      default:
        return <Hero setView={setView} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-rose-200 selection:text-rose-900">
      <main className="max-w-5xl mx-auto px-4 py-6 md:py-12 mb-16 md:mb-0">
        {renderContent()}
      </main>
      <Navigation currentView={currentView} setView={setView} />
    </div>
  );
};

export default App;