import React, { useState } from 'react';
import { generateItinerary } from '../services/geminiService';
import { ItineraryResponse } from '../types';
import { MapPin, Clock, Calendar, Loader2, Sparkles, Navigation } from 'lucide-react';

export const ItineraryGenerator: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ItineraryResponse | null>(null);
  
  // Form State
  const [days, setDays] = useState(3);
  const [location, setLocation] = useState('Tokyo');
  const [interests, setInterests] = useState<string[]>([]);

  const interestOptions = ['Anime/Manga', 'History/Shrines', 'Food/Ramen', 'Nature/Gardens', 'Shopping', 'Nightlife', 'Traditional Art'];

  const toggleInterest = (interest: string) => {
    setInterests(prev => 
      prev.includes(interest) ? prev.filter(i => i !== interest) : [...prev, interest]
    );
  };

  const handleGenerate = async () => {
    if (interests.length === 0) {
      alert("Please select at least one interest!");
      return;
    }
    setLoading(true);
    try {
      const data = await generateItinerary(days, interests, location);
      setResult(data);
    } catch (e) {
      console.error(e);
      alert("Failed to generate itinerary. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-slate-900">AI Trip Planner</h2>
        <p className="text-slate-600">Tell us what you love, and we'll design your perfect Japan trip.</p>
      </div>

      {!result && (
        <div className="bg-white rounded-2xl p-6 md:p-8 shadow-sm border border-slate-100 space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Destination</label>
              <select 
                value={location} 
                onChange={(e) => setLocation(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-rose-500 outline-none"
              >
                <option value="Tokyo">Tokyo (Capital & Modern)</option>
                <option value="Kyoto">Kyoto (Tradition & Temples)</option>
                <option value="Osaka">Osaka (Food & Nightlife)</option>
                <option value="Hokkaido">Hokkaido (Nature & Snow)</option>
                <option value="Okinawa">Okinawa (Beaches)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Duration (Days)</label>
              <input 
                type="number" 
                min={1} 
                max={14} 
                value={days} 
                onChange={(e) => setDays(parseInt(e.target.value))}
                className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-rose-500 outline-none"
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="block text-sm font-medium text-slate-700">Interests</label>
            <div className="flex flex-wrap gap-2">
              {interestOptions.map(option => (
                <button
                  key={option}
                  onClick={() => toggleInterest(option)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    interests.includes(option)
                      ? 'bg-rose-500 text-white shadow-md shadow-rose-200'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full py-4 bg-gradient-to-r from-rose-500 to-orange-500 text-white rounded-xl font-bold shadow-lg shadow-orange-200 hover:shadow-xl transition-all disabled:opacity-70 flex items-center justify-center gap-2"
          >
            {loading ? (
              <><Loader2 className="animate-spin" /> Planning your trip...</>
            ) : (
              <><Sparkles /> Generate Itinerary</>
            )}
          </button>
        </div>
      )}

      {result && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-rose-100">
            <h3 className="text-2xl font-bold text-slate-900">{result.title}</h3>
            <p className="text-slate-600 mt-2 leading-relaxed">{result.summary}</p>
            <button 
                onClick={() => setResult(null)}
                className="mt-4 text-sm text-rose-600 font-medium hover:underline"
            >
                Start Over
            </button>
          </div>

          <div className="space-y-6">
            {result.itinerary.map((day, idx) => (
              <div key={idx} className="bg-white rounded-2xl shadow-sm overflow-hidden border border-slate-100">
                <div className="bg-slate-50 p-4 border-b border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="bg-rose-500 text-white font-bold px-3 py-1 rounded-lg text-sm">Day {day.day}</span>
                    <span className="font-semibold text-slate-700">{day.theme}</span>
                  </div>
                </div>
                <div className="p-4 md:p-6 space-y-6">
                  {day.activities.map((activity, actIdx) => (
                    <div key={actIdx} className="flex gap-4 group">
                      <div className="flex flex-col items-center">
                        <div className="w-2 h-2 rounded-full bg-indigo-400 mt-2"></div>
                        {actIdx !== day.activities.length - 1 && <div className="w-0.5 h-full bg-slate-100 my-1"></div>}
                      </div>
                      <div className="flex-1 pb-2">
                        <div className="flex flex-wrap items-baseline gap-2 mb-1">
                          <span className="text-sm font-bold text-indigo-600 font-mono bg-indigo-50 px-2 py-0.5 rounded">{activity.time}</span>
                          <h4 className="font-bold text-slate-800">{activity.activity}</h4>
                        </div>
                        <p className="text-sm text-slate-600 mb-2">{activity.description}</p>
                        <div className="flex items-center text-xs text-slate-400 gap-1">
                          <MapPin size={12} />
                          {activity.location}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};