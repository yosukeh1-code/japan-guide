import React from 'react';
import { Map, BookOpen, MessageCircle, Home, Plane } from 'lucide-react';
import { View } from '../types';

interface NavigationProps {
  currentView: View;
  setView: (view: View) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: View.HOME, label: 'Home', icon: Home },
    { id: View.PLANNER, label: 'Trip Planner', icon: Plane },
    { id: View.CULTURE, label: 'Culture Guide', icon: BookOpen },
    { id: View.CHAT, label: 'AI Assistant', icon: MessageCircle },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-slate-200 z-50 md:top-0 md:bottom-auto md:px-8">
      <div className="max-w-5xl mx-auto px-4">
        <div className="flex justify-between md:justify-start md:gap-8 items-center h-16">
          <div className="hidden md:flex items-center gap-2 mr-8">
            <div className="w-8 h-8 bg-rose-500 rounded-full flex items-center justify-center text-white font-bold">J</div>
            <span className="text-xl font-bold bg-gradient-to-r from-rose-500 to-indigo-600 bg-clip-text text-transparent">JapanEase</span>
          </div>
          
          <div className="flex w-full md:w-auto justify-between md:justify-start md:gap-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`flex flex-col md:flex-row items-center gap-1 md:gap-2 p-2 rounded-lg transition-colors ${
                  currentView === item.id
                    ? 'text-rose-600 md:bg-rose-50'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <item.icon size={20} strokeWidth={currentView === item.id ? 2.5 : 2} />
                <span className="text-xs md:text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};