import React from 'react';
import { Utensils, Train, HandHeart, Coffee, Info } from 'lucide-react';
import { CultureTopic } from '../types';

export const CultureGuide: React.FC = () => {
  const topics: CultureTopic[] = [
    {
      id: 'dining',
      title: 'Dining Etiquette',
      icon: 'Utensils',
      content: 'Japanese dining is full of small rituals. The most famous is "Itadakimasu" before eating and "Gochisousama" after.',
      tips: [
        'Never stick chopsticks vertically into rice (reminds of funerals).',
        'Do not pass food from chopstick to chopstick.',
        'Slurping noodles (ramen/soba) is acceptable and shows enjoyment.',
        'Pour drinks for others, not yourself.'
      ]
    },
    {
      id: 'public',
      title: 'Trains & Public',
      icon: 'Train',
      content: 'Trains are quiet zones. Respect the silence and order.',
      tips: [
        'Set your phone to silent mode (Manner Mode).',
        'Do not talk on the phone while on the train.',
        'Line up neatly on the platform markers.',
        'Priority seats are strictly for elderly, pregnant, or disabled.'
      ]
    },
    {
      id: 'bowing',
      title: 'Bowing & Greetings',
      icon: 'HandHeart',
      content: 'Bowing (Ojigi) is the universal greeting.',
      tips: [
        'A slight nod (15°) is casual.',
        'A deeper bow (30-45°) is for respect or apology.',
        'No need to combine bowing with handshakes.',
        'Wait for the other person to finish bowing before you rise.'
      ]
    },
    {
      id: 'onsen',
      title: 'Onsen (Hot Springs)',
      icon: 'Coffee',
      content: 'Communal bathing is a big part of culture, but has strict rules.',
      tips: [
        'You must wash your body thoroughly BEFORE entering the bath water.',
        'No swimsuits allowed in traditional onsens.',
        'Keep your towel out of the water (place it on your head).',
        'Tattoos may be restricted in some public onsens.'
      ]
    }
  ];

  const getIcon = (name: string) => {
    switch (name) {
      case 'Utensils': return <Utensils className="w-6 h-6 text-rose-500" />;
      case 'Train': return <Train className="w-6 h-6 text-indigo-500" />;
      case 'HandHeart': return <HandHeart className="w-6 h-6 text-emerald-500" />;
      case 'Coffee': return <Coffee className="w-6 h-6 text-orange-500" />;
      default: return <Info className="w-6 h-6" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto pb-20">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-slate-900 mb-4">Cultural Etiquette Guide</h2>
        <p className="text-slate-600">Travel with confidence by understanding the local customs.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {topics.map((topic) => (
          <div key={topic.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 bg-slate-50 rounded-xl">
                {getIcon(topic.icon)}
              </div>
              <h3 className="text-xl font-bold text-slate-800">{topic.title}</h3>
            </div>
            <p className="text-slate-600 mb-6 text-sm leading-relaxed">{topic.content}</p>
            
            <div className="bg-slate-50 rounded-xl p-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Key Tips</h4>
              <ul className="space-y-3">
                {topic.tips.map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-slate-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0"></span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};