import React from 'react';
import { View } from '../types';
import { ArrowRight, Star } from 'lucide-react';

interface HeroProps {
  setView: (view: View) => void;
}

export const Hero: React.FC<HeroProps> = ({ setView }) => {
  return (
    <div className="space-y-12 pb-20">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-indigo-900 text-white shadow-xl min-h-[500px] flex items-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/1200/800?grayscale&blur=2" 
            alt="Japan Background" 
            className="w-full h-full object-cover opacity-30 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-indigo-900 via-transparent to-transparent"></div>
        </div>
        
        <div className="relative z-10 px-8 md:px-12 max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-1.5 rounded-full text-sm font-medium text-rose-200 border border-white/10 mb-6">
            <Star size={14} fill="currentColor" />
            <span>AI-Powered Travel Companion</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
            Experience Japan<br/>
            <span className="text-rose-400">Like a Local.</span>
          </h1>
          <p className="text-lg text-indigo-100 mb-8 max-w-xl leading-relaxed">
            Navigate the culture, language, and sights with ease. Create custom itineraries and get real-time advice from your AI guide.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => setView(View.PLANNER)}
              className="px-8 py-4 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-rose-900/20 flex items-center justify-center gap-2"
            >
              Plan My Trip <ArrowRight size={18} />
            </button>
            <button 
              onClick={() => setView(View.CHAT)}
              className="px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/20 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
            >
              Ask AI Guide
            </button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        <div 
            onClick={() => setView(View.PLANNER)}
            className="group cursor-pointer bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-lg transition-all hover:-translate-y-1"
        >
          <div className="w-12 h-12 bg-rose-50 rounded-xl flex items-center justify-center text-rose-500 mb-4 group-hover:scale-110 transition-transform">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Smart Itineraries</h3>
          <p className="text-slate-600 text-sm leading-relaxed">Generated in seconds based on your specific interests and schedule.</p>
        </div>

        <div 
            onClick={() => setView(View.CULTURE)}
            className="group cursor-pointer bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-lg transition-all hover:-translate-y-1"
        >
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-500 mb-4 group-hover:scale-110 transition-transform">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">Etiquette Guide</h3>
          <p className="text-slate-600 text-sm leading-relaxed">Master the Do's and Don'ts of dining, trains, and onsens.</p>
        </div>

        <div 
            onClick={() => setView(View.CHAT)}
            className="group cursor-pointer bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-lg transition-all hover:-translate-y-1"
        >
          <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-500 mb-4 group-hover:scale-110 transition-transform">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">24/7 Assistant</h3>
          <p className="text-slate-600 text-sm leading-relaxed">Instant answers for translation, navigation, and food recommendations.</p>
        </div>
      </div>
    </div>
  );
};