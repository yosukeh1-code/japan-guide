export enum View {
  HOME = 'HOME',
  PLANNER = 'PLANNER',
  CULTURE = 'CULTURE',
  CHAT = 'CHAT'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface ItineraryActivity {
  time: string;
  activity: string;
  description: string;
  location: string;
}

export interface ItineraryDay {
  day: number;
  theme: string;
  activities: ItineraryActivity[];
}

export interface ItineraryResponse {
  title: string;
  summary: string;
  itinerary: ItineraryDay[];
}

export interface CultureTopic {
  id: string;
  title: string;
  icon: string;
  content: string;
  tips: string[];
}