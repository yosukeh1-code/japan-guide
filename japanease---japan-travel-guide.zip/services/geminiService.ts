import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ItineraryResponse } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Schema for Itinerary Generation
const itinerarySchema: Schema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "A catchy title for the trip" },
    summary: { type: Type.STRING, description: "A brief summary of the trip experience" },
    itinerary: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.INTEGER },
          theme: { type: Type.STRING, description: "Theme of the day (e.g., Traditional Kyoto, Modern Tokyo)" },
          activities: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                time: { type: Type.STRING, description: "Suggested time (e.g., 09:00 AM)" },
                activity: { type: Type.STRING, description: "Name of the activity or place" },
                description: { type: Type.STRING, description: "Brief description of what to do there" },
                location: { type: Type.STRING, description: "City or District" }
              }
            }
          }
        }
      }
    }
  }
};

export const generateItinerary = async (
  days: number,
  interests: string[],
  location: string
): Promise<ItineraryResponse> => {
  const model = "gemini-2.5-flash";
  const prompt = `Create a detailed ${days}-day travel itinerary for a trip to ${location}, Japan. 
  The traveler is interested in: ${interests.join(", ")}.
  Ensure the plan is logistics-friendly and includes specific Japanese cultural experiences.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: itinerarySchema,
        systemInstruction: "You are an expert Japan travel guide. Provide practical, exciting, and culturally rich itineraries.",
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as ItineraryResponse;
  } catch (error) {
    console.error("Error generating itinerary:", error);
    throw error;
  }
};

export const chatWithGuide = async (message: string, history: { role: 'user' | 'model', text: string }[]): Promise<string> => {
    // Transform history to Gemini format if needed, but for single turn or simple chat logic we can just use generateContent for now
    // or use a ChatSession. Here we use a stateless approach for simplicity in this demo, 
    // simply passing context in the prompt or using the chat API if we were maintaining a long session object.
    // For this implementation, we will use a fresh chat instance or simply pass context.
    
    // Using chat session for better context
    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: "You are a helpful, polite, and knowledgeable guide for international travelers in Japan. Help with translation, etiquette, food, and travel tips. Keep answers concise and practical.",
        },
        history: history.map(h => ({
            role: h.role,
            parts: [{ text: h.text }]
        }))
    });

    const result = await chat.sendMessage({ message });
    return result.text || "I apologize, I couldn't process that request.";
};